package com.luminos.developers.classmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUpScreen extends AppCompatActivity {

    // Global edit texts
    public EditText usernameEntry;
    public EditText emailEntry;
    public EditText passwordEntry;
    public EditText passwordReEntry;

    public void signUpButtonIsPressed(View signUpButton){
        usernameEntry = findViewById(R.id.username_entry);
        passwordEntry = findViewById(R.id.password_entry);
        emailEntry = findViewById(R.id.email_entry);
        passwordReEntry = findViewById(R.id.password_re_entry);

        String username = usernameEntry.getText().toString();
        String pass = passwordEntry.getText().toString();
        String repass = passwordReEntry.getText().toString();

        if (pass.equals(repass)){
            // FireBase Config
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("UserData").child(username).child("Information");

            myRef.child(username);
            myRef.child("username").setValue(usernameEntry.getText().toString());
            myRef.child("password").setValue(passwordEntry.getText().toString());
            myRef.child("email").setValue(emailEntry.getText().toString());

            Toast.makeText(this, "You have signed up! Now login to continue", Toast.LENGTH_LONG).show();

            Intent intent = new Intent(this, LoginScreen.class);
            startActivity(intent);
        }
        else{
            Toast.makeText(this, "Password and repeat password do not match", Toast.LENGTH_LONG).show();
        }

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_screen);
    }
}
